package br.com.unipac.protocoloapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProtocoloApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProtocoloApiApplication.class, args);
	}

}
